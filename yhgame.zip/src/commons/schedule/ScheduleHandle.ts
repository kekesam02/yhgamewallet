import schedule, {Job} from "node-schedule";
import {Context, Telegraf} from "telegraf";
import GameScheduleHandle from "./GameScheduleHandle";
import WalletScheduleHandle from "./WalletScheduleHandle";
import AESUtils from "../AESUtils";

/**
 * 定时任务控制器
 */
class ScheduleHandle {

    /**
     * 正在工作的定时器列表、运行结束需要关闭
     */
    public static currJobList: Array<Job> = []

    /**
     * 游戏是否已经开始
     *      true: 已经开始游戏、定时器正在执行
     *      false: 游戏还没有开始运行
     */
    public static isStartPC28 = false

    public static pc28Config = GameScheduleHandle.pc28Config

    /**
     * 开启pc28调度器
     * @param bot
     */
    public static startPC28 = async (bot: Telegraf<Context>) => {
        await GameScheduleHandle.startPC28(bot)
    }

    public static bot: Telegraf<Context>

    /**
     * 钱包调度器
     * @param bot
     */
    public static initWallet = (bot: Telegraf<Context>) => {
        // 测试每30秒执行一次定时器
        // let job = schedule.scheduleJob('10 * * * * *',()=>{
        //     console.log('scheduleCronstyle:' + new Date());
        //     this.bot = bot
        //     WalletScheduleHandle.init(bot)
        // })
        // 每天凌晨执行一次定时器
        let job = schedule.scheduleJob('0 0 * * *',()=>{
                this.bot = bot
                WalletScheduleHandle.init(bot)
        })
        this.currJobList.push(job)
    }

    /**
     * 进程结束需要关闭正在工作的定时器
     */
    public static closeJobs = () => {
        this.currJobList.forEach(item => {
            item.cancel()
        })
    }
}

export default ScheduleHandle
